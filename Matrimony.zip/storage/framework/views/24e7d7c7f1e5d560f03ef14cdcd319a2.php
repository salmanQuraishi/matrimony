<footer class="footer">
  <div class="container-fluid d-flex justify-content-between">

    <div class="copyright">
      2025, made with <i class="fa fa-heart heart text-danger"></i> by
      <a href="Webtis.in">Webtis</a>
    </div>
    <div>
      Distributed by
      <a target="_blank" href="Webtis.in">Webtis</a>.
    </div>
  </div>
</footer>
</div>
</div>
<!--   Core JS Files   -->
<script src="<?php echo e(asset('/')); ?>assets/js/core/jquery-3.7.1.min.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/js/core/popper.min.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/js/core/bootstrap.min.js"></script>

<!-- jQuery Scrollbar -->
<script src="<?php echo e(asset('/')); ?>assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

<!-- Datatables -->
<script src="<?php echo e(asset('/')); ?>assets/js/plugin/datatables/datatables.min.js"></script>

<!-- Sweet Alert -->
<script src="<?php echo e(asset('/')); ?>assets/js/plugin/sweetalert/sweetalert.min.js"></script>

<!-- Kaiadmin JS -->
<script src="<?php echo e(asset('/')); ?>assets/js/kaiadmin.min.js"></script>

<!-- Kaiadmin DEMO methods, don't include it in your project! -->
<script src="<?php echo e(asset('/')); ?>assets/js/setting-demo2.js"></script><?php /**PATH D:\Laravel\Matrimony\resources\views/layouts/footer.blade.php ENDPATH**/ ?>