<?php
    $selectedValue = $selected ?? old($name);
?>

<div class="form-group <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error has-feedback <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    <label for="<?php echo e($id); ?>"><?php echo e($label); ?></label>
    <select class="form-select form-control" id="<?php echo e($id); ?>" name="<?php echo e($name); ?>">
        <option value="<?php echo e($label); ?>"><?php echo e($label); ?></option>
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $optionValue = is_object($option) ? $option->rid : $option;
                $optionText = is_object($option) ? $option->name : $option;
            ?>
            <option value="<?php echo e($optionValue); ?>" <?php echo e($selectedValue == $optionValue ? 'selected' : ''); ?>>
                <?php echo e($optionText); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH D:\Laravel\Matrimony\resources\views/components/form-select.blade.php ENDPATH**/ ?>