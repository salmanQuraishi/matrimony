<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <div class="container">
    <div class="page-inner">
      <!-- Card -->
      <h3 class="fw-bold mb-3">Card</h3>
      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-primary card-round">
            <div class="card-body">
              <div class="row">
                <div class="col-5">
                  <div class="icon-big text-center">
                    <i class="fas fa-users"></i>
                  </div>
                </div>
                <div class="col-7 col-stats">
                  <div class="numbers">
                    <p class="card-category">Visitors</p>
                    <h4 class="card-title">1,294</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-info card-round">
            <div class="card-body">
              <div class="row">
                <div class="col-5">
                  <div class="icon-big text-center">
                    <i class="fas fa-user-check"></i>
                  </div>
                </div>
                <div class="col-7 col-stats">
                  <div class="numbers">
                    <p class="card-category">Subscribers</p>
                    <h4 class="card-title">1303</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-success card-round">
            <div class="card-body">
              <div class="row">
                <div class="col-5">
                  <div class="icon-big text-center">
                    <i class="fas fa-chart-pie"></i>
                  </div>
                </div>
                <div class="col-7 col-stats">
                  <div class="numbers">
                    <p class="card-category">Sales</p>
                    <h4 class="card-title">$ 1,345</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-secondary card-round">
            <div class="card-body">
              <div class="row">
                <div class="col-5">
                  <div class="icon-big text-center">
                    <i class="far fa-check-circle"></i>
                  </div>
                </div>
                <div class="col-7 col-stats">
                  <div class="numbers">
                    <p class="card-category">Order</p>
                    <h4 class="card-title">576</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Card With Icon States Color -->
      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-round">
            <div class="card-body">
              <div class="row">
                <div class="col-5">
                  <div class="icon-big text-center">
                    <i class="icon-pie-chart text-warning"></i>
                  </div>
                </div>
                <div class="col-7 col-stats">
                  <div class="numbers">
                    <p class="card-category">Number</p>
                    <h4 class="card-title">150GB</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-round">
            <div class="card-body">
              <div class="row">
                <div class="col-5">
                  <div class="icon-big text-center">
                    <i class="icon-wallet text-success"></i>
                  </div>
                </div>
                <div class="col-7 col-stats">
                  <div class="numbers">
                    <p class="card-category">Revenue</p>
                    <h4 class="card-title">$ 1,345</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-round">
            <div class="card-body">
              <div class="row">
                <div class="col-5">
                  <div class="icon-big text-center">
                    <i class="icon-close text-danger"></i>
                  </div>
                </div>
                <div class="col-7 col-stats">
                  <div class="numbers">
                    <p class="card-category">Errors</p>
                    <h4 class="card-title">23</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-round">
            <div class="card-body">
              <div class="row">
                <div class="col-5">
                  <div class="icon-big text-center">
                    <i class="icon-social-twitter text-primary"></i>
                  </div>
                </div>
                <div class="col-7 col-stats">
                  <div class="numbers">
                    <p class="card-category">Followers</p>
                    <h4 class="card-title">+45K</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Card With Icon States Background -->
      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-round">
            <div class="card-body">
              <div class="row align-items-center">
                <div class="col-icon">
                  <div class="icon-big text-center icon-primary bubble-shadow-small">
                    <i class="fas fa-users"></i>
                  </div>
                </div>
                <div class="col col-stats ms-3 ms-sm-0">
                  <div class="numbers">
                    <p class="card-category">Visitors</p>
                    <h4 class="card-title">1,294</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-round">
            <div class="card-body">
              <div class="row align-items-center">
                <div class="col-icon">
                  <div class="icon-big text-center icon-info bubble-shadow-small">
                    <i class="fas fa-user-check"></i>
                  </div>
                </div>
                <div class="col col-stats ms-3 ms-sm-0">
                  <div class="numbers">
                    <p class="card-category">Subscribers</p>
                    <h4 class="card-title">1303</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-round">
            <div class="card-body">
              <div class="row align-items-center">
                <div class="col-icon">
                  <div class="icon-big text-center icon-success bubble-shadow-small">
                    <i class="fas fa-luggage-cart"></i>
                  </div>
                </div>
                <div class="col col-stats ms-3 ms-sm-0">
                  <div class="numbers">
                    <p class="card-category">Sales</p>
                    <h4 class="card-title">$ 1,345</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-round">
            <div class="card-body">
              <div class="row align-items-center">
                <div class="col-icon">
                  <div class="icon-big text-center icon-secondary bubble-shadow-small">
                    <i class="far fa-check-circle"></i>
                  </div>
                </div>
                <div class="col col-stats ms-3 ms-sm-0">
                  <div class="numbers">
                    <p class="card-category">Order</p>
                    <h4 class="card-title">576</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Row Card No Padding -->
      <div class="row row-card-no-pd">
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-round">
            <div class="card-body">
              <div class="row">
                <div class="col-5">
                  <div class="icon-big text-center">
                    <i class="icon-pie-chart text-warning"></i>
                  </div>
                </div>
                <div class="col-7 col-stats">
                  <div class="numbers">
                    <p class="card-category">Number</p>
                    <h4 class="card-title">150GB</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-round">
            <div class="card-body">
              <div class="row">
                <div class="col-5">
                  <div class="icon-big text-center">
                    <i class="icon-wallet text-success"></i>
                  </div>
                </div>
                <div class="col-7 col-stats">
                  <div class="numbers">
                    <p class="card-category">Revenue</p>
                    <h4 class="card-title">$ 1,345</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-round">
            <div class="card-body">
              <div class="row">
                <div class="col-5">
                  <div class="icon-big text-center">
                    <i class="icon-close text-danger"></i>
                  </div>
                </div>
                <div class="col-7 col-stats">
                  <div class="numbers">
                    <p class="card-category">Errors</p>
                    <h4 class="card-title">23</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="card card-stats card-round">
            <div class="card-body">
              <div class="row">
                <div class="col-5">
                  <div class="icon-big text-center">
                    <i class="icon-social-twitter text-primary"></i>
                  </div>
                </div>
                <div class="col-7 col-stats">
                  <div class="numbers">
                    <p class="card-category">Followers</p>
                    <h4 class="card-title">+45K</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4">
          <div class="card card-secondary">
            <div class="card-body skew-shadow">
              <h1>3,072</h1>
              <h5 class="op-8">Total conversations</h5>
              <div class="pull-right">
                <h3 class="fw-bold op-8">88%</h3>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-secondary bg-secondary-gradient">
            <div class="card-body bubble-shadow">
              <h1>188</h1>
              <h5 class="op-8">Total Sales</h5>
              <div class="pull-right">
                <h3 class="fw-bold op-8">25%</h3>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-secondary bg-secondary-gradient">
            <div class="card-body curves-shadow">
              <h1>12</h1>
              <h5 class="op-8">New Users</h5>
              <div class="pull-right">
                <h3 class="fw-bold op-8">70%</h3>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4">
          <div class="card card-secondary bg-secondary-gradient">
            <div class="card-body skew-shadow">
              <img src="assets/img/visa.svg" height="12.5" alt="Visa Logo" />
              <h2 class="py-4 mb-0">1234 **** **** 5678</h2>
              <div class="row">
                <div class="col-8 pe-0">
                  <h3 class="fw-bold mb-1">Sultan Ghani</h3>
                  <div class="text-small text-uppercase fw-bold op-8">
                    Card Holder
                  </div>
                </div>
                <div class="col-4 ps-0 text-end">
                  <h3 class="fw-bold mb-1">4/26</h3>
                  <div class="text-small text-uppercase fw-bold op-8">
                    Expired
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-secondary bg-secondary-gradient">
            <div class="card-body bubble-shadow">
              <img src="assets/img/visa.svg" height="12.5" alt="Visa Logo" />
              <h2 class="py-4 mb-0">1234 **** **** 5678</h2>
              <div class="row">
                <div class="col-8 pe-0">
                  <h3 class="fw-bold mb-1">Sultan Ghani</h3>
                  <div class="text-small text-uppercase fw-bold op-8">
                    Card Holder
                  </div>
                </div>
                <div class="col-4 ps-0 text-end">
                  <h3 class="fw-bold mb-1">4/26</h3>
                  <div class="text-small text-uppercase fw-bold op-8">
                    Expired
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-secondary bg-secondary-gradient">
            <div class="card-body curves-shadow">
              <img src="assets/img/visa.svg" height="12.5" alt="Visa Logo" />
              <h2 class="py-4 mb-0">1234 **** **** 5678</h2>
              <div class="row">
                <div class="col-8 pe-0">
                  <h3 class="fw-bold mb-1">Sultan Ghani</h3>
                  <div class="text-small text-uppercase fw-bold op-8">
                    Card Holder
                  </div>
                </div>
                <div class="col-4 ps-0 text-end">
                  <h3 class="fw-bold mb-1">4/26</h3>
                  <div class="text-small text-uppercase fw-bold op-8">
                    Expired
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4">
          <div class="card">
            <div class="card-body pb-0">
              <div class="h1 fw-bold float-end text-primary">+5%</div>
              <h2 class="mb-2">17</h2>
              <p class="text-muted">Users online</p>
              <div class="pull-in sparkline-fix">
                <div id="lineChart"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card">
            <div class="card-body pb-0">
              <div class="h1 fw-bold float-end text-danger">-3%</div>
              <h2 class="mb-2">27</h2>
              <p class="text-muted">New Users</p>
              <div class="pull-in sparkline-fix">
                <div id="lineChart2"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card">
            <div class="card-body pb-0">
              <div class="h1 fw-bold float-end text-warning">+7%</div>
              <h2 class="mb-2">213</h2>
              <p class="text-muted">Transactions</p>
              <div class="pull-in sparkline-fix">
                <div id="lineChart3"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4">
          <div class="card card-primary bg-primary-gradient">
            <div class="card-body pb-0">
              <div class="h1 fw-bold float-end">+5%</div>
              <h2 class="mb-2">17</h2>
              <p>Users online</p>
              <div class="pull-in sparkline-fix chart-as-background">
                <div id="lineChart4"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-black">
            <div class="card-body pb-0">
              <div class="h1 fw-bold float-end">-3%</div>
              <h2 class="mb-2">27</h2>
              <p>New Users</p>
              <div class="pull-in sparkline-fix chart-as-background">
                <div id="lineChart5"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-success bg-success2">
            <div class="card-body pb-0">
              <div class="h1 fw-bold float-end">+7%</div>
              <h2 class="mb-2">213</h2>
              <p>Transactions</p>
              <div class="pull-in sparkline-fix chart-as-background">
                <div id="lineChart6"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-xl-3">
          <div class="card">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h5><b>Todays Income</b></h5>
                  <p class="text-muted">All Customs Value</p>
                </div>
                <h3 class="text-info fw-bold">$170</h3>
              </div>
              <div class="progress progress-sm">
                <div class="progress-bar bg-info w-75" role="progressbar" aria-valuenow="75" aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
              <div class="d-flex justify-content-between mt-2">
                <p class="text-muted mb-0">Change</p>
                <p class="text-muted mb-0">75%</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-xl-3">
          <div class="card">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h5><b>Total Revenue</b></h5>
                  <p class="text-muted">All Customs Value</p>
                </div>
                <h3 class="text-success fw-bold">$120</h3>
              </div>
              <div class="progress progress-sm">
                <div class="progress-bar bg-success w-25" role="progressbar" aria-valuenow="25" aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
              <div class="d-flex justify-content-between mt-2">
                <p class="text-muted mb-0">Change</p>
                <p class="text-muted mb-0">25%</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-xl-3">
          <div class="card">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h5><b>New Orders</b></h5>
                  <p class="text-muted">Fresh Order Amount</p>
                </div>
                <h3 class="text-danger fw-bold">15</h3>
              </div>
              <div class="progress progress-sm">
                <div class="progress-bar bg-danger w-50" role="progressbar" aria-valuenow="50" aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
              <div class="d-flex justify-content-between mt-2">
                <p class="text-muted mb-0">Change</p>
                <p class="text-muted mb-0">50%</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-xl-3">
          <div class="card">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h5><b>New Users</b></h5>
                  <p class="text-muted">Joined New User</p>
                </div>
                <h3 class="text-secondary fw-bold">12</h3>
              </div>
              <div class="progress progress-sm">
                <div class="progress-bar bg-secondary w-25" role="progressbar" aria-valuenow="25" aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
              <div class="d-flex justify-content-between mt-2">
                <p class="text-muted mb-0">Change</p>
                <p class="text-muted mb-0">25%</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row row-card-no-pd mt--2">
        <div class="col-12 col-sm-6 col-md-6 col-xl-3">
          <div class="card">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h5><b>Todays Income</b></h5>
                  <p class="text-muted">All Customs Value</p>
                </div>
                <h3 class="text-info fw-bold">$170</h3>
              </div>
              <div class="progress progress-sm">
                <div class="progress-bar bg-info w-75" role="progressbar" aria-valuenow="75" aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
              <div class="d-flex justify-content-between mt-2">
                <p class="text-muted mb-0">Change</p>
                <p class="text-muted mb-0">75%</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-xl-3">
          <div class="card">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h5><b>Total Revenue</b></h5>
                  <p class="text-muted">All Customs Value</p>
                </div>
                <h3 class="text-success fw-bold">$120</h3>
              </div>
              <div class="progress progress-sm">
                <div class="progress-bar bg-success w-25" role="progressbar" aria-valuenow="25" aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
              <div class="d-flex justify-content-between mt-2">
                <p class="text-muted mb-0">Change</p>
                <p class="text-muted mb-0">25%</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-xl-3">
          <div class="card">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h5><b>New Orders</b></h5>
                  <p class="text-muted">Fresh Order Amount</p>
                </div>
                <h3 class="text-danger fw-bold">15</h3>
              </div>
              <div class="progress progress-sm">
                <div class="progress-bar bg-danger w-50" role="progressbar" aria-valuenow="50" aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
              <div class="d-flex justify-content-between mt-2">
                <p class="text-muted mb-0">Change</p>
                <p class="text-muted mb-0">50%</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-xl-3">
          <div class="card">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h5><b>New Users</b></h5>
                  <p class="text-muted">Joined New User</p>
                </div>
                <h3 class="text-secondary fw-bold">12</h3>
              </div>
              <div class="progress progress-sm">
                <div class="progress-bar bg-secondary w-25" role="progressbar" aria-valuenow="25" aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
              <div class="d-flex justify-content-between mt-2">
                <p class="text-muted mb-0">Change</p>
                <p class="text-muted mb-0">25%</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-6 col-sm-4 col-lg-2">
          <div class="card">
            <div class="card-body p-3 text-center">
              <div class="text-end text-success">
                6%
                <i class="fa fa-chevron-up"></i>
              </div>
              <div class="h1 m-0">43</div>
              <div class="text-muted mb-3">New Tickets</div>
            </div>
          </div>
        </div>
        <div class="col-6 col-sm-4 col-lg-2">
          <div class="card">
            <div class="card-body p-3 text-center">
              <div class="text-end text-danger">
                -3%
                <i class="fa fa-chevron-down"></i>
              </div>
              <div class="h1 m-0">17</div>
              <div class="text-muted mb-3">Closed Today</div>
            </div>
          </div>
        </div>
        <div class="col-6 col-sm-4 col-lg-2">
          <div class="card">
            <div class="card-body p-3 text-center">
              <div class="text-end text-success">
                9%
                <i class="fa fa-chevron-up"></i>
              </div>
              <div class="h1 m-0">7</div>
              <div class="text-muted mb-3">New Replies</div>
            </div>
          </div>
        </div>
        <div class="col-6 col-sm-4 col-lg-2">
          <div class="card">
            <div class="card-body p-3 text-center">
              <div class="text-end text-success">
                3%
                <i class="fa fa-chevron-up"></i>
              </div>
              <div class="h1 m-0">27.3K</div>
              <div class="text-muted mb-3">Followers</div>
            </div>
          </div>
        </div>
        <div class="col-6 col-sm-4 col-lg-2">
          <div class="card">
            <div class="card-body p-3 text-center">
              <div class="text-end text-danger">
                -2%
                <i class="fa fa-chevron-down"></i>
              </div>
              <div class="h1 m-0">$95</div>
              <div class="text-muted mb-3">Daily Earnings</div>
            </div>
          </div>
        </div>
        <div class="col-6 col-sm-4 col-lg-2">
          <div class="card">
            <div class="card-body p-3 text-center">
              <div class="text-end text-danger">
                -1%
                <i class="fa fa-chevron-down"></i>
              </div>
              <div class="h1 m-0">621</div>
              <div class="text-muted mb-3">Products</div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-sm-6 col-lg-3">
          <div class="card p-3">
            <div class="d-flex align-items-center">
              <span class="stamp stamp-md bg-secondary me-3">
                <i class="fa fa-dollar-sign"></i>
              </span>
              <div>
                <h5 class="mb-1">
                  <b><a href="#">132 <small>Sales</small></a></b>
                </h5>
                <small class="text-muted">12 waiting payments</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="card p-3">
            <div class="d-flex align-items-center">
              <span class="stamp stamp-md bg-success me-3">
                <i class="fa fa-shopping-cart"></i>
              </span>
              <div>
                <h5 class="mb-1">
                  <b><a href="#">78 <small>Orders</small></a></b>
                </h5>
                <small class="text-muted">32 shipped</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="card p-3">
            <div class="d-flex align-items-center">
              <span class="stamp stamp-md bg-danger me-3">
                <i class="fa fa-users"></i>
              </span>
              <div>
                <h5 class="mb-1">
                  <b><a href="#">1,352 <small>Members</small></a></b>
                </h5>
                <small class="text-muted">163 registered today</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="card p-3">
            <div class="d-flex align-items-center">
              <span class="stamp stamp-md bg-warning me-3">
                <i class="fa fa-comment-alt"></i>
              </span>
              <div>
                <h5 class="mb-1">
                  <b><a href="#">132 <small>Comments</small></a></b>
                </h5>
                <small class="text-muted">16 waiting</small>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\Laravel\Matrimony\resources\views/base/widgets.blade.php ENDPATH**/ ?>