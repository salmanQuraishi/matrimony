<div class="form-group  <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error has-feedback <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    <label for="<?php echo e($id); ?>">Status</label>
    <select class="form-select form-control" id="<?php echo e($id); ?>" name="<?php echo e($name); ?>">
        <option value="" selected disabled>Choose a Status</option>
        <option value="show" <?php echo e(old($name, $selected) == 'show' ? 'selected' : ''); ?>>Show</option>
        <option value="hide" <?php echo e(old($name, $selected) == 'hide' ? 'selected' : ''); ?>>Hide</option>
    </select>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH D:\Laravel\Matrimony\resources\views/components/status-select.blade.php ENDPATH**/ ?>